# MODifieRDev

[Tutorial](https://ddeweerd.github.io/index.html)

[Documentation](https://github.com/ddeweerd/MODifieRDev/blob/Devel/MODifieRDev.pdf)

